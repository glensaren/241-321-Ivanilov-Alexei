<?php

    return [
        'host'=>'localhost',
        'dbname'=>'project-321',
        'user'=>'root',
        'password'=>''
    ];