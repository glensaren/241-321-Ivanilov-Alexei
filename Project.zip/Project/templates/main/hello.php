<?php require(dirname(__DIR__).'/header.php');?>
    Hello, <?=$name;?>
<?php require(dirname(__DIR__).'/footer.html');?>
